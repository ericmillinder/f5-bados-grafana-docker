import {AdmdbConfigCtrl} from './components/config/config';

export {
  AdmdbConfigCtrl as ConfigCtrl
};
