export class AdmdbConfigCtrl {
  constructor() { }
}
AdmdbConfigCtrl.templateUrl = 'components/config/config.html';