import {pluginName} from './properties';
import {DiagramCtrl} from './diagramControl';
/*import {loadPluginCss} from 'app/plugins/sdk';

loadPluginCss({
  dark: 'plugins/'+pluginName+'/libs/mermaid/dist/mermaid.css',
  light: 'plugins/'+pluginName+'/libs/mermaid/dist/mermaid.css'
});*/

export {
	DiagramCtrl as PanelCtrl
}; 